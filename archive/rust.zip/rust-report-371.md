# Rust Report

Run : 371
Branch : main
Commit : 46d5ffffead9be7c0c114a91a7348bb52a93c9a2
Date : Mon Aug 10 02:28:05 UTC 2026


## Cargo fmt

## Cargo clippy

## Cargo test
   Compiling libc v0.2.189
   Compiling cfg-if v1.0.4
   Compiling typenum v1.20.1
   Compiling zerofrom v0.1.8
   Compiling stable_deref_trait v1.2.1
   Compiling smallvec v1.15.2
   Compiling yoke v0.8.3
   Compiling zerovec v0.11.6
   Compiling cpufeatures v0.2.17
   Compiling pin-project-lite v0.2.17
   Compiling memchr v2.8.3
   Compiling generic-array v0.14.7
   Compiling subtle v2.6.1
   Compiling tinystr v0.8.3
   Compiling getrandom v0.2.17
   Compiling jobserver v0.1.35
   Compiling rand_core v0.6.4
   Compiling litemap v0.8.2
   Compiling cc v1.4.2
   Compiling crypto-common v0.1.7
   Compiling block-buffer v0.10.4
   Compiling scopeguard v1.2.0
   Compiling writeable v0.6.3
   Compiling once_cell v1.21.4
   Compiling futures-core v0.3.33
   Compiling icu_locale_core v2.2.0
   Compiling lock_api v0.4.14
   Compiling serde_core v1.0.229
   Compiling potential_utf v0.1.5
   Compiling zerotrie v0.2.4
   Compiling utf8_iter v1.0.4
   Compiling icu_collections v2.2.0
   Compiling icu_provider v2.2.0
   Compiling num-traits v0.2.19
   Compiling icu_properties_data v2.2.0
   Compiling parking_lot_core v0.9.12
   Compiling icu_normalizer_data v2.2.0
   Compiling mio v1.2.2
   Compiling socket2 v0.6.5
   Compiling bytes v1.12.1
   Compiling futures-sink v0.3.33
   Compiling parking_lot v0.12.5
   Compiling icu_normalizer v2.2.0
   Compiling serde v1.0.229
   Compiling icu_properties v2.2.0
   Compiling equivalent v1.0.2
   Compiling iana-time-zone v0.1.65
   Compiling percent-encoding v2.3.2
   Compiling form_urlencoded v1.2.2
   Compiling digest v0.10.7
   Compiling futures-task v0.3.33
   Compiling allocator-api2 v0.2.21
   Compiling foldhash v0.1.5
   Compiling slab v0.4.12
   Compiling futures-io v0.3.33
   Compiling itoa v1.0.18
   Compiling hashbrown v0.15.5
   Compiling futures-util v0.3.33
   Compiling thiserror v2.0.20
   Compiling crossbeam-utils v0.8.22
   Compiling idna_adapter v1.2.2
   Compiling zmij v1.0.23
   Compiling hashbrown v0.17.1
   Compiling idna v1.1.0
   Compiling crc-catalog v2.5.0
   Compiling parking v2.2.1
   Compiling event-listener v5.4.2
   Compiling indexmap v2.14.0
   Compiling crc v3.4.0
   Compiling url v2.5.8
   Compiling serde_json v1.0.151
   Compiling libsqlite3-sys v0.30.1
   Compiling hashlink v0.10.0
   Compiling crossbeam-queue v0.3.13
   Compiling either v1.17.0
   Compiling futures-intrusive v0.5.0
   Compiling base64 v0.22.1
   Compiling log v0.4.33
   Compiling sha2 v0.10.9
   Compiling tokio v1.53.1
   Compiling zstd-sys v2.0.16+zstd.1.5.7
   Compiling spin v0.9.9
   Compiling tracing-core v0.1.36
   Compiling errno v0.3.14
   Compiling ryu v1.0.23
   Compiling signal-hook-registry v1.4.8
   Compiling serde_urlencoded v0.7.1
   Compiling tracing v0.1.44
   Compiling flume v0.11.1
   Compiling getrandom v0.4.3
   Compiling futures-executor v0.3.33
   Compiling chrono v0.4.45
   Compiling futures-channel v0.3.33
   Compiling atoi v2.0.0
   Compiling inout v0.1.4
   Compiling tokio-stream v0.1.19
   Compiling aho-corasick v1.1.5
   Compiling base64ct v1.8.3
   Compiling regex-syntax v0.8.11
   Compiling regex-automata v0.4.18
   Compiling sqlx-core v0.8.6
   Compiling cipher v0.4.4
   Compiling bzip2-sys v0.1.13+1.0.8
   Compiling sqlx-sqlite v0.8.6
   Compiling zerocopy v0.8.56
   Compiling uuid v1.24.0
   Compiling hmac v0.12.1
   Compiling universal-hash v0.5.1
   Compiling adler2 v2.0.1
   Compiling simd-adler32 v0.3.10
   Compiling opaque-debug v0.3.1
   Compiling hex v0.4.3
   Compiling sqlx-macros-core v0.8.6
   Compiling polyval v0.6.2
   Compiling miniz_oxide v0.8.9
   Compiling ppv-lite86 v0.2.21
   Compiling zstd-safe v5.0.2+zstd.1.5.2
   Compiling crc32fast v1.5.0
   Compiling aes v0.8.4
   Compiling password-hash v0.4.2
   Compiling time-core v0.1.9
   Compiling powerfmt v0.2.0
   Compiling tinyvec_macros v0.1.1
   Compiling linux-raw-sys v0.12.1
   Compiling lazy_static v1.5.0
   Compiling deranged v0.5.8
   Compiling nu-ansi-term v0.50.3
   Compiling num-conv v0.2.2
   Compiling bitflags v2.13.1
   Compiling sharded-slab v0.1.7
   Compiling rustix v1.1.4
   Compiling tinyvec v1.12.0
   Compiling time v0.3.55
   Compiling sqlx-macros v0.8.6
   Compiling pbkdf2 v0.11.0
   Compiling flate2 v1.1.9
   Compiling bzip2 v0.4.4
   Compiling rand_chacha v0.3.1
   Compiling zstd v0.11.2+zstd.1.5.2
   Compiling ghash v0.5.1
   Compiling ctr v0.9.2
   Compiling regex v1.13.1
   Compiling matchers v0.2.0
   Compiling password-hash v0.5.0
   Compiling tracing-log v0.2.0
   Compiling sha1 v0.10.7
   Compiling aead v0.5.2
   Compiling thread_local v1.1.10
   Compiling byteorder v1.5.0
   Compiling fastrand v2.5.0
   Compiling same-file v1.0.6
   Compiling constant_time_eq v0.1.5
   Compiling walkdir v2.5.0
   Compiling zip v0.6.6
   Compiling tempfile v3.27.0
   Compiling sqlx v0.8.6
   Compiling tracing-subscriber v0.3.23
   Compiling aes-gcm v0.10.3
   Compiling flexi_logger v0.29.8
   Compiling pbkdf2 v0.12.2
   Compiling rand v0.8.7
   Compiling anyhow v1.0.104
   Compiling unicode-normalization v0.1.25
   Compiling base64 v0.21.7
   Compiling the-last-signal-server v0.1.0 (/home/runner/work/The-last-signal-/The-last-signal-/server_rust)
error[E0425]: cannot find value `echec_loot` in this scope
   --> src/gameplay/tresor.rs:351:13
    |
351 |             echec_loot
    |             ^^^^^^^^^^
    |
help: a local variable with a similar name exists
    |
351 |             echecs_loot
    |                  +

warning: unused imports: `Pbkdf2` and `rand_core::RngCore`
  --> src/utils/save/encryptions.rs:20:9
   |
20 |         rand_core::RngCore,
   |         ^^^^^^^^^^^^^^^^^^
...
23 |     Pbkdf2,
   |     ^^^^^^
   |
   = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

error[E0560]: struct `Tresor` has no field named `echec_loot`
   --> src/gameplay/tresor.rs:351:13
    |
351 |             echec_loot
    |             ^^^^^^^^^^ unknown field
    |
help: a field with a similar name exists
    |
351 |             echecs_loot
    |                  +

error[E0308]: mismatched types
   --> src/gameplay/tresor.rs:409:9
    |
409 | /         for _ in 0..loot.admin {
410 | |             let objet = self.tirer_objet(
411 | |                 "Artefact admin",
412 | |                 &mut rng,
...   |
422 | |             *objets.entry(objet).or_insert(0) += quantite;
423 | |         }
    | |_________^ expected `HashMap<String, u32>`, found `()`
    |
    = note: expected struct `HashMap<std::string::String, u32>`
            found unit type `()`
    = note: `for` loops evaluate to unit type `()`
help: consider returning a value here
    |
423 ~         }
424 +         /* `HashMap<std::string::String, u32>` value */
    |

error[E0277]: the trait bound `std::string::String: Borrow<(std::string::String, std::string::String)>` is not satisfied
   --> src/gameplay/tresor.rs:485:18
    |
485 |             .get(&(nom_table.to_string(), objet.clone()))
    |              --- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ the trait `Borrow<(std::string::String, std::string::String)>` is not implemented for `std::string::String`
    |              |
    |              required by a bound introduced by this call
    |
help: the trait `Borrow<(std::string::String, std::string::String)>` is not implemented for `std::string::String`
      but trait `Borrow<str>` is implemented for it
   --> /rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/alloc/src/str.rs:229:0
    = help: for that trait implementation, expected `str`, found `(std::string::String, std::string::String)`
note: required by a bound in `HashMap::<K, V, S, A>::get`
   --> /rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/std/src/collections/hash/map.rs:1035:4

error[E0308]: mismatched types
   --> src/gameplay/tresor.rs:521:41
    |
521 |                 self.echecs_loot.insert(cle, 0);
    |                                  ------ ^^^ expected `String`, found `(String, String)`
    |                                  |
    |                                  arguments to this method are incorrect
    |
    = note: expected struct `std::string::String`
                found tuple `(std::string::String, std::string::String)`
note: method defined here
   --> /rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/std/src/collections/hash/map.rs:1333:11

error[E0308]: mismatched types
   --> src/gameplay/tresor.rs:524:41
    |
524 |                 *self.echecs_loot.entry(cle).or_insert(0) += 1;
    |                                   ----- ^^^ expected `String`, found `(String, String)`
    |                                   |
    |                                   arguments to this method are incorrect
    |
    = note: expected struct `std::string::String`
                found tuple `(std::string::String, std::string::String)`
help: the return type of this call is `(std::string::String, std::string::String)` due to the type of the argument passed
   --> src/gameplay/tresor.rs:524:18
    |
524 |                 *self.echecs_loot.entry(cle).or_insert(0) += 1;
    |                  ^^^^^^^^^^^^^^^^^^^^^^^---^
    |                                         |
    |                                         this argument influences the return type of `entry`
note: method defined here
   --> /rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/std/src/collections/hash/map.rs:1013:11

error[E0277]: the trait bound `std::string::String: Borrow<(std::string::String, std::string::String)>` is not satisfied
   --> src/gameplay/tresor.rs:566:18
    |
566 |             .get(&(categorie.to_string(), objet.clone()))
    |              --- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ the trait `Borrow<(std::string::String, std::string::String)>` is not implemented for `std::string::String`
    |              |
    |              required by a bound introduced by this call
    |
help: the trait `Borrow<(std::string::String, std::string::String)>` is not implemented for `std::string::String`
      but trait `Borrow<str>` is implemented for it
   --> /rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/alloc/src/str.rs:229:0
    = help: for that trait implementation, expected `str`, found `(std::string::String, std::string::String)`
note: required by a bound in `HashMap::<K, V, S, A>::get`
   --> /rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/std/src/collections/hash/map.rs:1035:4

error[E0308]: mismatched types
   --> src/gameplay/tresor.rs:605:41
    |
605 |                 self.echecs_loot.insert(cle, 0);
    |                                  ------ ^^^ expected `String`, found `(String, String)`
    |                                  |
    |                                  arguments to this method are incorrect
    |
    = note: expected struct `std::string::String`
                found tuple `(std::string::String, std::string::String)`
note: method defined here
   --> /rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/std/src/collections/hash/map.rs:1333:11

error[E0308]: mismatched types
   --> src/gameplay/tresor.rs:608:41
    |
608 |                 *self.echecs_loot.entry(cle).or_insert(0) += 1;
    |                                   ----- ^^^ expected `String`, found `(String, String)`
    |                                   |
    |                                   arguments to this method are incorrect
    |
    = note: expected struct `std::string::String`
                found tuple `(std::string::String, std::string::String)`
help: the return type of this call is `(std::string::String, std::string::String)` due to the type of the argument passed
   --> src/gameplay/tresor.rs:608:18
    |
608 |                 *self.echecs_loot.entry(cle).or_insert(0) += 1;
    |                  ^^^^^^^^^^^^^^^^^^^^^^^---^
    |                                         |
    |                                         this argument influences the return type of `entry`
note: method defined here
   --> /rustc/8bab26f4f68e0e26f0bb7960be334d5b520ea452/library/std/src/collections/hash/map.rs:1013:11

warning: variable does not need to be mutable
   --> src/gameplay/objets.rs:120:13
    |
120 |         let mut objet = Objet::new(nom, image, quantite, TypeObjet::Equipement);
    |             ----^^^^^
    |             |
    |             help: remove this `mut`
    |
    = note: `#[warn(unused_mut)]` (part of `#[warn(unused)]`) on by default

warning: variable does not need to be mutable
   --> src/gameplay/objets.rs:245:13
    |
245 |         let mut objet = Objet::new(nom, image, quantite, TypeObjet::Potion);
    |             ----^^^^^
    |             |
    |             help: remove this `mut`

warning: variable does not need to be mutable
   --> src/gameplay/objets.rs:292:13
    |
292 |         let mut objet = Objet::new(nom, image, quantite, TypeObjet::Livre);
    |             ----^^^^^
    |             |
    |             help: remove this `mut`

Some errors have detailed explanations: E0277, E0308, E0425, E0560.
For more information about an error, try `rustc --explain E0277`.
warning: `the-last-signal-server` (lib) generated 4 warnings
error: could not compile `the-last-signal-server` (lib) due to 9 previous errors; 4 warnings emitted
warning: build failed, waiting for other jobs to finish...
warning: `the-last-signal-server` (lib test) generated 4 warnings (4 duplicates)
error: could not compile `the-last-signal-server` (lib test) due to 9 previous errors; 4 warnings emitted
