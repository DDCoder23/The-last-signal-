# Rust Report

Run : 492
Branch : main
Commit : 181eedec50e1b8f772b2fedad43be189b67af247
Date : Wed Aug 12 01:32:07 UTC 2026


## Cargo fmt

## Cargo clippy

## Cargo test
   Compiling libc v0.2.189
   Compiling cfg-if v1.0.4
   Compiling typenum v1.20.1
   Compiling zerofrom v0.1.8
   Compiling stable_deref_trait v1.2.1
   Compiling subtle v2.6.1
   Compiling yoke v0.8.3
   Compiling cpufeatures v0.2.17
   Compiling zerovec v0.11.6
   Compiling smallvec v1.15.2
   Compiling pin-project-lite v0.2.17
   Compiling memchr v2.8.3
   Compiling generic-array v0.14.7
   Compiling tinystr v0.8.3
   Compiling futures-core v0.3.34
   Compiling getrandom v0.2.17
   Compiling jobserver v0.1.35
   Compiling rand_core v0.6.4
   Compiling cc v1.4.2
   Compiling scopeguard v1.2.0
   Compiling crypto-common v0.1.7
   Compiling block-buffer v0.10.4
   Compiling writeable v0.6.3
   Compiling litemap v0.8.2
   Compiling once_cell v1.21.4
   Compiling lock_api v0.4.14
   Compiling icu_locale_core v2.2.0
   Compiling serde_core v1.0.229
   Compiling potential_utf v0.1.5
   Compiling zerotrie v0.2.4
   Compiling utf8_iter v1.0.4
   Compiling icu_collections v2.2.0
   Compiling icu_provider v2.2.0
   Compiling num-traits v0.2.19
   Compiling icu_properties_data v2.2.0
   Compiling icu_normalizer_data v2.2.0
   Compiling parking_lot_core v0.9.12
   Compiling digest v0.10.7
   Compiling socket2 v0.6.5
   Compiling mio v1.2.2
   Compiling bytes v1.12.1
   Compiling futures-sink v0.3.34
   Compiling parking_lot v0.12.5
   Compiling icu_normalizer v2.2.0
   Compiling serde v1.0.229
   Compiling icu_properties v2.2.0
   Compiling percent-encoding v2.3.2
   Compiling iana-time-zone v0.1.65
   Compiling equivalent v1.0.2
   Compiling form_urlencoded v1.2.2
   Compiling foldhash v0.1.5
   Compiling itoa v1.0.18
   Compiling futures-io v0.3.34
   Compiling allocator-api2 v0.2.21
   Compiling slab v0.4.12
   Compiling futures-task v0.3.34
   Compiling futures-util v0.3.34
   Compiling thiserror v2.0.20
   Compiling crossbeam-utils v0.8.22
   Compiling hashbrown v0.15.5
   Compiling idna_adapter v1.2.2
   Compiling idna v1.1.0
   Compiling zmij v1.0.23
   Compiling crc-catalog v2.5.0
   Compiling parking v2.2.1
   Compiling hashbrown v0.17.1
   Compiling serde_json v1.0.151
   Compiling indexmap v2.14.0
   Compiling url v2.5.8
   Compiling event-listener v5.4.2
   Compiling crc v3.4.0
   Compiling hashlink v0.10.0
   Compiling crossbeam-queue v0.3.13
   Compiling either v1.17.0
   Compiling futures-intrusive v0.5.0
   Compiling libsqlite3-sys v0.30.1
   Compiling log v0.4.33
   Compiling tokio v1.53.1
   Compiling sha2 v0.10.9
   Compiling zstd-sys v2.0.16+zstd.1.5.7
   Compiling spin v0.9.9
   Compiling tracing-core v0.1.36
   Compiling errno v0.3.14
   Compiling base64ct v1.8.3
   Compiling ryu v1.0.23
   Compiling tracing v0.1.44
   Compiling serde_urlencoded v0.7.1
   Compiling signal-hook-registry v1.4.8
   Compiling flume v0.11.1
   Compiling getrandom v0.4.3
   Compiling futures-executor v0.3.34
   Compiling chrono v0.4.45
   Compiling tokio-stream v0.1.19
   Compiling futures-channel v0.3.34
   Compiling atoi v2.0.0
   Compiling openssl-sys v0.9.117
   Compiling inout v0.1.4
   Compiling aho-corasick v1.1.5
   Compiling regex-syntax v0.8.11
   Compiling regex-automata v0.4.18
   Compiling sqlx-core v0.8.6
   Compiling cipher v0.4.4
   Compiling bzip2-sys v0.1.13+1.0.8
   Compiling bitflags v2.13.1
   Compiling base64 v0.22.1
   Compiling sqlx-sqlite v0.8.6
   Compiling zerocopy v0.8.56
   Compiling uuid v1.24.0
   Compiling hmac v0.12.1
   Compiling universal-hash v0.5.1
   Compiling adler2 v2.0.1
   Compiling simd-adler32 v0.3.10
   Compiling hex v0.4.3
   Compiling opaque-debug v0.3.1
   Compiling foreign-types-shared v0.1.1
   Compiling foreign-types v0.3.2
   Compiling polyval v0.6.2
   Compiling openssl v0.10.81
   Compiling sqlx-macros-core v0.8.6
   Compiling miniz_oxide v0.8.9
   Compiling zstd-safe v5.0.2+zstd.1.5.2
   Compiling crc32fast v1.5.0
   Compiling ppv-lite86 v0.2.21
   Compiling aes v0.8.4
   Compiling password-hash v0.4.2
   Compiling password-hash v0.5.0
   Compiling time-core v0.1.9
   Compiling deranged v0.5.8
   Compiling byteorder v1.5.0
   Compiling nu-ansi-term v0.50.3
   Compiling powerfmt v0.2.0
   Compiling num-conv v0.2.2
   Compiling tinyvec_macros v0.1.1
   Compiling linux-raw-sys v0.12.1
   Compiling lazy_static v1.5.0
   Compiling sharded-slab v0.1.7
   Compiling rustix v1.1.4
   Compiling tinyvec v1.12.0
   Compiling time v0.3.55
   Compiling zeroize v1.9.0
   Compiling pbkdf2 v0.11.0
   Compiling rand_chacha v0.3.1
   Compiling sqlx-macros v0.8.6
   Compiling flate2 v1.1.9
   Compiling bzip2 v0.4.4
   Compiling zstd v0.11.2+zstd.1.5.2
   Compiling ghash v0.5.1
   Compiling ctr v0.9.2
   Compiling regex v1.13.1
   Compiling matchers v0.2.0
   Compiling tracing-log v0.2.0
   Compiling blake2 v0.10.6
   Compiling sha1 v0.10.7
   Compiling aead v0.5.2
   Compiling thread_local v1.1.10
   Compiling fastrand v2.5.0
   Compiling constant_time_eq v0.1.5
   Compiling same-file v1.0.6
   Compiling fernet v0.2.2
   Compiling walkdir v2.5.0
   Compiling tempfile v3.27.0
   Compiling zip v0.6.6
   Compiling tracing-subscriber v0.3.23
   Compiling aes-gcm v0.10.3
   Compiling argon2 v0.5.3
   Compiling flexi_logger v0.29.8
   Compiling sqlx v0.8.6
   Compiling rand v0.8.7
   Compiling anyhow v1.0.104
   Compiling unicode-normalization v0.1.25
   Compiling pbkdf2 v0.12.2
   Compiling base64 v0.21.7
   Compiling the-last-signal-server v0.1.0 (/home/runner/work/The-last-signal-/The-last-signal-/server_rust)
error[E0583]: file not found for module `password`
 --> src/utils/mod.rs:3:1
  |
3 | pub mod password;
  | ^^^^^^^^^^^^^^^^^
  |
  = help: to create the module `password`, create file "src/utils/password.rs" or "src/utils/password/mod.rs"
  = note: if there is a `mod password` elsewhere in the crate already, import it with `use crate::...` instead

error[E0432]: unresolved import `crate::utils::vault`
 --> src/database/migrations.rs:4:19
  |
4 | use crate::utils::vault::decrypt_vault;
  |                   ^^^^^ could not find `vault` in `utils`

error[E0425]: cannot find value `password` in this scope
  --> src/database/migrations.rs:28:40
   |
28 |     let password1_hash = hash_password(password)
   |                                        ^^^^^^^^
   |
help: a local variable with a similar name exists
   |
28 |     let password1_hash = hash_password(password1)
   |                                                +

error[E0425]: cannot find value `password` in this scope
  --> src/database/migrations.rs:34:40
   |
34 |     let password2_hash = hash_password(password)
   |                                        ^^^^^^^^
   |
help: a local variable with a similar name exists
   |
34 |     let password2_hash = hash_password(password1)
   |                                                +

warning: unused imports: `Pbkdf2` and `rand_core::RngCore`
  --> src/utils/save/encryptions.rs:20:9
   |
20 |         rand_core::RngCore,
   |         ^^^^^^^^^^^^^^^^^^
...
23 |     Pbkdf2,
   |     ^^^^^^
   |
   = note: `#[warn(unused_imports)]` (part of `#[warn(unused)]`) on by default

error[E0308]: mismatched types
   --> src/database/vault.rs:16:18
    |
 16 |         .decrypt(&encrypted)
    |          ------- ^^^^^^^^^^ expected `&str`, found `&Vec<u8>`
    |          |
    |          arguments to this method are incorrect
    |
    = note: expected reference `&str`
               found reference `&Vec<u8>`
note: method defined here
   --> /home/runner/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/fernet-0.2.2/src/lib.rs:223:12
    |
223 |     pub fn decrypt(&self, token: &str) -> Result<Vec<u8>, DecryptionError> {
    |            ^^^^^^^

error[E0599]: no method named `ok_or` found for enum `Result<T, E>` in the current scope
  --> src/database/vault.rs:17:10
   |
15 |       let decrypted = cipher
   |  _____________________-
16 | |         .decrypt(&encrypted)
17 | |         .ok_or("Impossible de déchiffrer vault.enc")?;
   | |         -^^^^^ method not found in `Result<Vec<u8>, DecryptionError>`
   | |_________|
   |

warning: variable does not need to be mutable
   --> src/gameplay/objets.rs:120:13
    |
120 |         let mut objet = Objet::new(nom, image, quantite, TypeObjet::Equipement);
    |             ----^^^^^
    |             |
    |             help: remove this `mut`
    |
    = note: `#[warn(unused_mut)]` (part of `#[warn(unused)]`) on by default

warning: variable does not need to be mutable
   --> src/gameplay/objets.rs:245:13
    |
245 |         let mut objet = Objet::new(nom, image, quantite, TypeObjet::Potion);
    |             ----^^^^^
    |             |
    |             help: remove this `mut`

warning: variable does not need to be mutable
   --> src/gameplay/objets.rs:292:13
    |
292 |         let mut objet = Objet::new(nom, image, quantite, TypeObjet::Livre);
    |             ----^^^^^
    |             |
    |             help: remove this `mut`

Some errors have detailed explanations: E0308, E0425, E0432, E0583, E0599.
For more information about an error, try `rustc --explain E0308`.
warning: `the-last-signal-server` (lib) generated 4 warnings
error: could not compile `the-last-signal-server` (lib) due to 6 previous errors; 4 warnings emitted
warning: build failed, waiting for other jobs to finish...
warning: `the-last-signal-server` (lib test) generated 4 warnings (4 duplicates)
error: could not compile `the-last-signal-server` (lib test) due to 6 previous errors; 4 warnings emitted
